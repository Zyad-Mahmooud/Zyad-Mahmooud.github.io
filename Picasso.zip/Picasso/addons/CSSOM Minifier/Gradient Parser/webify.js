var GradientParser = (window.GradientParser || {});
